package com.aeyacin.todolist.base;

public class ModelBase {
}
