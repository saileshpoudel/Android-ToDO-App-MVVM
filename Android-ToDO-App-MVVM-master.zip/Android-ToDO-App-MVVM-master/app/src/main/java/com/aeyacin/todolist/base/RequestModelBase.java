package com.aeyacin.todolist.base;

public class RequestModelBase extends ModelBase {
}
