package com.aeyacin.todolist.model;

public enum OrderStatus {
    NAME, STATUS, DEADLINE, CREATEDATE
}
