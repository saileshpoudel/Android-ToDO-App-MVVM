package com.aeyacin.todolist.model;

public enum ProcessType {
    ADD, DELETE, UPDATE
}
