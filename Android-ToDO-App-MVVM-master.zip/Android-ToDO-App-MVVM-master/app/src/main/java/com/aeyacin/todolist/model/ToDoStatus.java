package com.aeyacin.todolist.model;

/**
 * Created by aeyacin on 2019-09-12.
 */
public enum ToDoStatus {
    TODO,
    COMPLETE
    , EXPIRED
    , EDIT

}
